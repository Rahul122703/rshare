import os

def rename_files_sequentially(directory):
    """Renames all files in a directory sequentially (1, 2, 3, ...).

    Args:
        directory: The path to the directory containing the files.
    """

    try:
        files = sorted(os.listdir(directory))  # Get sorted list of files
        count = 1

        for filename in files:
            filepath = os.path.join(directory, filename)

            if os.path.isfile(filepath):  # Ensure it's a file
                new_filename = str(count)
                file_extension = os.path.splitext(filename)[1]
                new_filepath = os.path.join(directory, new_filename + file_extension)

                os.rename(filepath, new_filepath)
                count += 1

        print(f"Renamed {count - 1} files in {directory}")

    except FileNotFoundError:
        print(f"Error: Directory not found: {directory}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage:
directory_path = r"C:\Users\XIE\Desktop\rahul sharma\images" # Use raw string for Windows paths
rename_files_sequentially(directory_path)